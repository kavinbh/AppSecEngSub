import asyncio
import aiohttp

async def fetch_data_from_api(url, session, timeout):
    """Fetches data from a single API endpoint asynchronously."""
    try:
        async with session.get(url, timeout=timeout) as response:
            response.raise_for_status()  # Raise an exception for bad status codes
            return await response.json()
    except asyncio.TimeoutError:
        print(f"Timeout occurred while fetching data from {url}")
        return None
    except aiohttp.ClientError as e:
        print(f"Error fetching data from {url}: {e}")
        return None
    except Exception as e:
        print(f"An unexpected error occurred: {e}")
        return None

async def fetch_data_concurrently(api_endpoints, timeout):
    """Fetches data from multiple API endpoints concurrently."""
    async with aiohttp.ClientSession() as session:
        tasks = [fetch_data_from_api(url, session, timeout) for url in api_endpoints]
        results = await asyncio.gather(*tasks, return_exceptions=True)
        return results

def lambda_handler(event, context):
    """AWS Lambda function handler."""
    api_endpoints = [
        "https://jsonplaceholder.typicode.com/todos/1",
        "https://jsonplaceholder.typicode.com/posts/1",
        "https://jsonplaceholder.typicode.com/comments/1"
    ]
    timeout = aiohttp.ClientTimeout(total=10)  # 10 seconds timeout

    try:
        results = asyncio.run(fetch_data_concurrently(api_endpoints, timeout))
        return {
            'statusCode': 200,
            'body': {'results': results}
        }
    except Exception as e:
        print(f"An error occurred in the Lambda function: {e}")
        return {
            'statusCode': 500,
            'body': {'error': 'An error occurred while fetching data'}
        }